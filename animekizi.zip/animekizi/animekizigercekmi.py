import pgzrun
import random
import time
#from pgzhelper import *

#####################################################

import math
import pygame
from pgzero.actor import Actor, POS_TOPLEFT, ANCHOR_CENTER, transform_anchor
from pgzero import game, loaders
import types
import sys
import time

mod = sys.modules['__main__']
_fullscreen = False

def set_fullscreen():
  global _fullscreen
  mod.screen.surface = pygame.display.set_mode((mod.WIDTH, mod.HEIGHT), pygame.FULLSCREEN)
  _fullscreen = True

def set_windowed():
  global _fullscreen
  mod.screen.surface = pygame.display.set_mode((mod.WIDTH, mod.HEIGHT))
  _fullscreen = False

def toggle_fullscreen():
  if _fullscreen:
    set_windowed()
  else:
    set_fullscreen()

def hide_mouse():
   pygame.mouse.set_visible(False)

def show_mouse():
   pygame.mouse.set_visible(True)

class Actor(Actor):
  def __init__(self, image, pos=POS_TOPLEFT, anchor=ANCHOR_CENTER, **kwargs):
    self._flip_x = False
    self._flip_y = False
    self._scale = 1
    self._mask = None
    self._animate_counter = 0
    self.fps = 5
    self.direction = 0
    super().__init__(image, pos, anchor, **kwargs)

  def distance_to(self, actor):
    dx = actor.x - self.x
    dy = actor.y - self.y
    return math.sqrt(dx**2 + dy**2)

  def direction_to(self, actor):
    dx = actor.x - self.x
    dy = self.y - actor.y

    angle = math.degrees(math.atan2(dy, dx))
    if angle > 0:
      return angle

    return 360 + angle

  def move_towards(self, actor, dist):
    angle = math.radians(self.direction_to(actor))
    dx = dist * math.cos(angle)
    dy = dist * math.sin(angle)
    self.x += dx
    self.y -= dy

  def point_towards(self, actor):
    print(self.direction_to(actor))
    self.angle = self.direction_to(actor)

  def move_in_direction(self, dist):
    angle = math.radians(self.direction)
    dx = dist * math.cos(angle)
    dy = dist * math.sin(angle)
    self.x += dx
    self.y -= dy

  def move_forward(self, dist):
    angle = math.radians(self.angle)
    dx = dist * math.cos(angle)
    dy = dist * math.sin(angle)
    self.x += dx
    self.y -= dy

  def move_left(self, dist):
    angle = math.radians(self.angle + 90)
    dx = dist * math.cos(angle)
    dy = dist * math.sin(angle)
    self.x += dx
    self.y -= dy

  def move_right(self, dist):
    angle = math.radians(self.angle - 90)
    dx = dist * math.cos(angle)
    dy = dist * math.sin(angle)
    self.x += dx
    self.y -= dy

  def move_back(self, dist):
    angle = math.radians(self.angle)
    dx = -dist * math.cos(angle)
    dy = -dist * math.sin(angle)
    self.x += dx
    self.y -= dy

  @property
  def images(self):
    return self._images

  @images.setter
  def images(self, images):
    self._images = images
    if len(self._images) != 0:
      self.image = self._images[0]

  def next_image(self):
    if self.image in self._images:
      current = self._images.index(self.image)
      if current == len(self._images) - 1:
        self.image = self._images[0]
      else:
        self.image = self._images[current + 1]
    else:
      self.image = self._images[0]

  def animate(self):
    now = int(time.time() * self.fps)
    if now != self._animate_counter:
      self._animate_counter = now
      self.next_image()

  @property
  def angle(self):
    return self._angle

  @angle.setter
  def angle(self, angle):
    self._angle = angle
    self._transform_surf()

  @property
  def scale(self):
    return self._scale

  @scale.setter
  def scale(self, scale):
    self._scale = scale
    self._transform_surf()

  @property
  def flip_x(self):
    return self._flip_x

  @flip_x.setter
  def flip_x(self, flip_x):
    self._flip_x = flip_x
    self._transform_surf()

  @property
  def flip_y(self):
    return self._flip_y

  @flip_y.setter
  def flip_y(self, flip_y):
    self._flip_y = flip_y
    self._transform_surf()

  @property
  def image(self):
    return self._image_name

  @image.setter
  def image(self, image):
    self._image_name = image
    self._orig_surf = self._surf = loaders.images.load(image)
    self._update_pos()
    self._transform_surf()

  def _transform_surf(self):
    self._surf = self._orig_surf
    p = self.pos

    if self._scale != 1:
      size = self._orig_surf.get_size()
      self._surf = pygame.transform.scale(self._surf, (int(size[0] * self.scale), int(size[1] * self.scale)))
    if self._flip_x:
      self._surf = pygame.transform.flip(self._surf, True, False)
    if self._flip_y:
      self._surf = pygame.transform.flip(self._surf, False, True)

    self._surf = pygame.transform.rotate(self._surf, self._angle)

    self.width, self.height = self._surf.get_size()
    w, h = self._orig_surf.get_size()
    ax, ay = self._untransformed_anchor
    anchor = transform_anchor(ax, ay, w, h, self._angle)
    self._anchor = (anchor[0] * self.scale, anchor[1] * self.scale)

    self.pos = p
    self._mask = None

  def collidepoint_pixel(self, x, y=0):
    if isinstance(x, tuple):
      y = x[1]
      x = x[0]
    if self._mask == None:
      self._mask = pygame.mask.from_surface(self._surf)

    xoffset = int(x - self.left)
    yoffset = int(y - self.top)
    if xoffset < 0 or yoffset < 0:
      return 0

    width, height = self._mask.get_size()
    if xoffset > width or yoffset > height:
      return 0

    return self._mask.get_at((xoffset, yoffset))

  def collide_pixel(self, actor):
    for a in [self, actor]:
      if a._mask == None:
        a._mask = pygame.mask.from_surface(a._surf)

    xoffset = int(actor.left - self.left)
    yoffset = int(actor.top - self.top)

    return self._mask.overlap(actor._mask, (xoffset, yoffset))

  def collidelist_pixel(self, actors):
    for i in range(len(actors)):
      if self.collide_pixel(actors[i]):
        return i
    return -1

  def collidelistall_pixel(self, actors):
    collided = []
    for i in range(len(actors)):
      if self.collide_pixel(actors[i]):
        collided.append(i)
    return collided

  def obb_collidepoints(self, actors):
    angle = math.radians(self._angle)
    costheta = math.cos(angle)
    sintheta = math.sin(angle)
    width, height = self._orig_surf.get_size()
    half_width = width / 2
    half_height = height / 2

    i = 0
    for actor in actors:
      tx = actor.x - self.x
      ty = actor.y - self.y
      rx = tx * costheta - ty * sintheta
      ry = ty * costheta + tx * sintheta

      if rx > -half_width and rx < half_width and ry > -half_height and ry < half_height:
        return i
      i += 1

    return -1

  def obb_collidepoint(self, x, y=0):
    if isinstance(x, tuple):
      y = x[1]
      x = x[0]
    angle = math.radians(self._angle)
    costheta = math.cos(angle)
    sintheta = math.sin(angle)
    width, height = self._orig_surf.get_size()
    half_width = width / 2
    half_height = height / 2

    tx = x - self.x
    ty = y - self.y
    rx = tx * costheta - ty * sintheta
    ry = ty * costheta + tx * sintheta

    if rx > -half_width and rx < half_width and ry > -half_height and ry < half_height:
      return True

    return False

  def circle_collidepoints(self, radius, actors):
    rSquare = radius ** 2

    i = 0
    for actor in actors:
      dSquare = (actor.x - self.x)**2 + (actor.y - self.y)**2

      if dSquare < rSquare:
        return i
      i += 1

    return -1

  def circle_collidepoint(self, radius, x, y=0):
    if isinstance(x, tuple):
      y = x[1]
      x = x[0]
    rSquare = radius ** 2
    dSquare = (x - self.x)**2 + (y - self.y)**2

    if dSquare < rSquare:
      return True

    return False


  def draw(self):
    game.screen.blit(self._surf, self.topleft)

  def get_rect(self):
    return self._rect

########################################################


WIDTH = 1000
HEIGHT = 600
TITLE = "Anime Kızları Gerçek Mi?"
FPS = 60
mod = "tanıt"
puan = 0
animesayi = 0
para = 0
sayi = 40
impo = random.randint(1,6)
start = time.time()
kb = 0

iks = WIDTH/2
ye = WIDTH/2
buttonx = Actor("panel", (iks, ye))

basma = 0

music.play("beep")

bg = Actor("bg")
a1 = Actor("a1", (100, 200))
a2 = Actor("a2", (450, 200))
a3 = Actor("a3", (800, 200))
a4 = Actor("a4", (100, 400))
a5 = Actor("a5", (450, 400))
a6 = Actor("a6", (800, 400))
sonic = Actor("sonic", (700, 500))
rock = Actor("rockçı", (300, 500))
demon = Actor("iblis", (500, 500))
osman = Actor("osman", (300, 300))
sumo = Actor("sumo", (700, 300))
kiss = Actor("öpücük", (500, 300))
slap = Actor("tokat", (500, 300))
fes = Actor("fes", (500, 250))
girl = Actor("animekızı", (960, 45))
sikke = Actor("sikke", (40, 45))
cross = Actor("çarpı", (100, 500))
button1 = Actor("panel", (500, 150))
button2 = Actor("panel", (1025, 40))
button3 = Actor("panel", (-25, 40))
button4 = Actor("panel", (WIDTH/2, HEIGHT/2))
button5 = Actor("panel", (WIDTH / 2, 100))
button6 = Actor("panel", (WIDTH/2, 500))
button7 = Actor("panel", (WIDTH / 2, 500))
dialog1 = Actor("dialog", (310, 200))
dialog2 = Actor("dialog", (710, 200))

secim = random.randint(1, 4)
artis = 5
azalma = 5
mousePos = []
toplam = ["a1", "a2", "a3", "a4", "a5", "a6"]
enemies = []
animes = []
slaps = []
kisses = []
kontrol = 0
aless = 4
ahiz = 2
dhiz = 2

bitti = 0

def draw():
    global enemies
    global animes
    global kontrol
    global aless
    global secim
    global para
    global bitti
    global impo
    global a1,a2,a3,a4,a5,a6

    bg.draw()
    if mod == "tanıt":
        screen.draw.text("OYUNU YAPAN: UMAY DÖNMEZ\n\nKodlar: Umay Dönmez\n\nGörseller: Umay Dönmez\n\nMüzik: Umay Dönmez\n\nHikaye: Umay Dönmez\n\nGitHub: umay03-code\n\nLinkedIn: umay-dönmez-03690369u\n\nInstagram: u_d_369\n\nnot: oyuna detaylandırma ve hata çözme güncellemesi gelebilir.\n\n(geçmek için space tuşu)",center=(WIDTH/2, HEIGHT/2), color="black", fontsize=30)

    if mod == "start":
        buttonx.draw()
        screen.draw.text("OYNA", center=(iks, ye), fontsize=30)
        screen.draw.text("E ile tokat (sumo-kun'a), Q ile öpücük (anime kızlarına) at\noyun butonu için SAĞ tık, diğer tıklamalar için SOL tık kullan.", center=(500, 100), color = "black", fontsize=30)

    if mod == "menu1":
        osman.draw()
        sumo.draw()
        dialog1.draw()
        screen.draw.text("Anime kızları gerçektir,\nsumo-kun!", center=(300, 200), fontsize=30)

    if mod == "menu2":
        osman.draw()
        sumo.draw()
        dialog2.draw()
        screen.draw.text("AHAHAH, OSMAN AGAA, \nGÜLDÜRME BENİ!", center=(700, 200), fontsize=26)

    if mod == "menu3":
        osman.draw()
        sumo.draw()
        button1.draw()
        screen.draw.text("SUMO-KUN'A ANİME KIZLARINI KANITLA", center=(500, 150), fontsize=26)

    if mod == "oyun":
        osman.x, osman.y = 500, 300
        slap.draw()
        kiss.draw()
        osman.draw()
        if kontrol == 1:
            fes.draw()
        for i in enemies:
            i.draw()
        for i in animes:
            i.draw()
        button2.draw()
        button3.draw()
        sikke.draw()
        girl.draw()
        screen.draw.text(str(puan), pos=(85, 35), color="black", fontsize=50)
        screen.draw.text(str(animesayi), pos=(850, 35), color="black", fontsize=50)
        screen.draw.text(str(sayi-timer_int), pos=(WIDTH/2, 35), color="black", fontsize=50)

    if mod == "ikinci":
        button2.draw()
        button3.draw()
        button4.draw()
        sikke.draw()
        girl.draw()
        sonic.draw()
        rock.draw()
        demon.draw()
        screen.draw.text(str(puan), pos=(85, 35), color="black", fontsize=50)
        screen.draw.text(str(animesayi), pos=(850, 35), color="black", fontsize=50)
        screen.draw.text("oh bea hepsini tokatladım\nşimdi ek puan almak için kostüm almalıyım!\nrastgele kostüm için tuşa tıkla.", center=(WIDTH / 2, 35), color="black", fontsize=30)
        screen.draw.text("rastgele kıyafet seç!", center=(WIDTH / 2, HEIGHT / 2), color="black", fontsize=50)

    if mod == "ucuncu":
        global secim
        if secim == 1:
            osman.image = "rockçı"
            screen.draw.text("hahah dostum, gitarımla dünyayı sallamaya hazırım!", center=(WIDTH / 2, 400), color="black", fontsize=20)
        if secim == 2:
            osman.image = "sonic"
            screen.draw.text("hmm, ben mi? anime kızlarına inanıyorum tabi...", center=(WIDTH / 2, 400), color="black", fontsize=20)
        if secim == 3:
            osman.image = "iblis"
            screen.draw.text("madem sumo-kun inatçı, ben onun gözünü korkutmasını bilirimss", center=(WIDTH / 2, 400), color="black", fontsize=20)
        if secim == 4:
            osman.image = "osman"
            screen.draw.text("gerçek güç osmanlının!!", center=(WIDTH / 2, 400),
                             color="black", fontsize=20)
        button5.draw()
        screen.draw.text("işte kostümün bu. (s bas)", center=(WIDTH / 2, 100), color="black", fontsize=30)
        osman.draw()

    if mod == "secti":
        if secim == 1:
            osman.image = "rockçı"
            osman.draw()
            button7.draw()
            ek = random.randint(15, 20)
            bonus = animesayi * ek
            screen.draw.text("oyuna devam et! (w bas)", center=(WIDTH / 2, 500), color="black", fontsize=40)
            if bonus >= 150:
                kontrol = 1
                fes.draw()
                screen.draw.text("topladığım tüm anime kızları sana\nseçtiğin kıyafete göre puan verdi\nve seni çok beğendikleri için hediye olarak\nsana yardımcı olacak bir fes verdiler!", center=(WIDTH / 2, HEIGHT / 4), color="black", fontsize=30)
            else:
                kontrol = -1
                screen.draw.text("topladığım tüm anime kızları sana\nseçtiğin kıyafete göre puan verdi\nve seni çok varoş buldular\nsana yardımcı olmayacaklar :/",center=(WIDTH / 2, HEIGHT / 4), color="black", fontsize=30)

        if secim == 2:
            osman.image = "sonic"
            osman.draw()
            button7.draw()
            ek = random.randint(10, 15)
            bonus = animesayi * ek
            screen.draw.text("oyuna devam et! (w bas)", center=(WIDTH / 2, 500), color="black", fontsize=40)
            if bonus >= 320:
                kontrol = 1
                fes.draw()
                screen.draw.text("topladığım tüm anime kızları sana\nseçtiğin kıyafete göre puan verdi\nve seni çok beğendikleri için hediye olarak\nsana yardımcı olacak bir fes verdiler!", center=(WIDTH / 2, HEIGHT / 4), color="black", fontsize=30)
            else:
                kontrol = -1

        if secim == 3:
            osman.image = "iblis"
            osman.draw()
            button7.draw()
            ek = random.randint(5, 20)
            bonus = animesayi * ek
            screen.draw.text("oyuna devam et! (w bas)", center=(WIDTH / 2, 500), color="black", fontsize=40)
            if bonus >= 320:
                kontrol = 1
                fes.draw()
                screen.draw.text("topladığım tüm anime kızları sana\nseçtiğin kıyafete göre puan verdi\nve seni çok beğendikleri için hediye olarak\nsana yardımcı olacak bir fes verdiler!", center=(WIDTH / 2, HEIGHT / 4), color="black", fontsize=30)
            else:
                kontrol = -1

        if secim == 4:
            osman.image = "osman"
            osman.draw()
            button7.draw()
            ek = random.randint(5, 10)
            bonus = animesayi * ek
            screen.draw.text("oyuna devam et! (w bas)", center=(WIDTH / 2, 500), color="black", fontsize=40)
            if bonus >= 320:
                kontrol = 1
                fes.draw()
                screen.draw.text("topladığım tüm anime kızları sana\nseçtiğin kıyafete göre puan verdi\nve seni çok beğendikleri için hediye olarak\nsana yardımcı olacak bir fes verdiler!",center=(WIDTH / 2, HEIGHT / 4), color="black", fontsize=30)
            else:
                kontrol = -1

    if mod == "haber":
        osman.draw()
        if kontrol == 1:
            fes.draw()
        screen.draw.text("paraları konuşturma vaktii!! kaç sikken var?\nsesini duyurmak için sikke 400  vererek haberlere konuşmalısın.", center=(WIDTH / 2, 100), color="black", fontsize=40)
        if puan >= 400:
            para = 1
            screen.draw.text( "hesabını kontrol ettim vee, haberlere videonu verdim.\nayrıca harem kapısına giriş hakkı kazandın! (geçmek için x)",center=(WIDTH / 2, 400), color="black", fontsize=40)
        else:
            screen.draw.text("hesabını kontrol ettim vee, fakir fukarasın yaw\nosmanlıya yakışmıyorsun cıkcıkcık... (geçmek için x)",center=(WIDTH / 2, 400), color="black", fontsize=40)
            para = -1


    if mod == "eleme":
        a1.draw()
        a2.draw()
        a3.draw()
        a4.draw()
        a5.draw()
        a6.draw()
        a1 = Actor("a1", (100, 200))
        a2 = Actor("a2", (450, 200))
        a3 = Actor("a3", (800, 200))
        a4 = Actor("a4", (100, 400))
        a5 = Actor("a5", (450, 400))
        a6 = Actor("a6", (800, 400))
        screen.draw.text("1",center=(100, 300), color="black", fontsize=40)
        screen.draw.text("2", center=(450, 300), color="black", fontsize=40)
        screen.draw.text("3", center=(800, 300), color="black", fontsize=40)
        screen.draw.text("4", center=(100, 500), color="black", fontsize=40)
        screen.draw.text("5", center=(450, 500), color="black", fontsize=40)
        screen.draw.text("6", center=(800, 500), color="black", fontsize=40)
        screen.draw.text("içlerinden birini seç. dikkat et, haini seçersen işin biter!\nseçtiğin anime kızı gerçekse osmanlı hamamı senin olacak!!\nseçim için sayı tuşlarını kullan.", center =(500,50), color = "black", fontsize=40)

    if mod == "son":

        if kb == 1:
            a1.x,a1.y = 400, 500
            a1.draw()
        if kb == 2:
            a1.x, a1.y = 400, 500
            a2.draw()
        if kb == 3:
            a1.x, a1.y = 400, 500
            a3.draw()
        if kb == 4:
            a1.x, a1.y = 400, 500
            a4.draw()
        if kb == 5:
            a1.x, a1.y = 400, 500
            a5.draw()
        if kb == 6:
            a1.x, a1.y = 400, 500
            a6.draw()

        osman.x,osman.y = 300, 500
        osman.draw()

        screen.draw.text("TÜM DÜNYA ARTIK ANİME KIZLARINI BİLİYOR!\nsumo-kun artık sana sataşamaz, anime kızlarıyla anime evrenine uçmaya hazırsındır umarım.\nv bas hadi!",center=(500,100), color = "black", fontsize = 30)


    if mod == "lose":
        screen.draw.text("BU ÖNEMLİ GÖREVDE BAŞARISIZ OLDUN!\nSUMO-KUN SENİ MİDEYE İNDİRDİ!!", center=(WIDTH/2, HEIGHT/2), color="black", fontsize=40)
        bitti = 1

    if mod == "win":
        screen.draw.text("ANİME KIZLARINI DÜNYAYA KANITLADIN!\nTÜM ANİME KIZLARIYLA DÜNYAYI ELE GEÇİRDİNİZ!!", center=(WIDTH/2, HEIGHT/2), color="black", fontsize=40)
        bitti = 1


def animemove():
    global mod
    global animes
    global ahiz
    for i in range(len(animes)):
        animes[i].move_forward(ahiz)


def enemymove():
    global mod
    global enemies
    global dhiz
    for i in range(len(enemies)):
        enemies[i].move_forward(dhiz)


def animedonme():
    global mod
    global animes
    for i in range(len(animes)):
        animes[i].angle = animes[i].angle_to(osman)


def enemydonme():
    global mod
    global enemies
    for i in range(len(enemies)):
        enemies[i].angle = enemies[i].angle_to(osman)


def newenemy():
    global enemies
    side = random.randint(1, 4)

    if side == 1:
        y = random.randint(-1000, -10)
        x = random.randint(-200, -10)
    if side == 2:
        y = random.randint(-1000, -10)
        x = random.randint(1010, 1200)
    if side == 3:
        y = random.randint(610, 1000)
        x = random.randint(-1000, -10)
    if side == 4:
        y = random.randint(610, 1000)
        x = random.randint(1010, 1200)

    enemy = Actor("sumo", (x, y))
    if len(enemies) <= 3:
        enemies.append(enemy)


def newanime():
    global animes
    global toplam

    side = random.randint(1, 4)
    if side == 1:
        y = random.randint(-1000, -10)
        x = random.randint(-200, -10)
    if side == 2:
        y = random.randint(-1000, -10)
        x = random.randint(1010, 1200)
    if side == 3:
        y = random.randint(610, 1000)
        x = random.randint(-1000, -10)
    if side == 4:
        y = random.randint(610, 1000)
        x = random.randint(1010, 1200)

    anime = Actor(toplam[random.randint(0, 5)], (x, y))
    if len(animes) <= aless:
        animes.append(anime)


def sumocarpisma():
    global enemies
    global animes
    global slaps
    global kisses
    global mod
    global puan
    for i in range(len(enemies)):
        if osman.colliderect(enemies[i]):
            mod = "lose"

        for q in range(len(slaps)):
            if enemies[i].colliderect(slaps[q]):
                enemies.pop(i)
                slaps[q].pos = (10000, 10000)
                slaps.pop(q)
                newenemy()
                puan += artis
                break


def sumohatacarpisma():
    global mod
    global puan
    global enemies
    global animes
    global slaps
    global kisses
    for i in range(len(animes)):
        if osman.colliderect(animes[i]):
            mod = "lose"

        for q in range(len(slaps)):
            if animes[i].colliderect(slaps[q]):
                animes.pop(i)
                slaps[q].pos = (10000, 10000)
                slaps.pop(q)
                newanime()
                puan -= azalma
                break


def animecarpisma():
    global mod
    global puan
    global animesayi
    global enemies
    global animes
    global slaps
    global kisses

    for i in range(len(animes)):
        if osman.colliderect(animes[i]):
            mod = "lose"

        for q in range(len(kisses)):
            if animes[i].colliderect(kisses[q]):
                animes.pop(i)
                kisses[q].pos = (10000, 10000)
                kisses.pop(q)
                newanime()
                animesayi += 1
                puan += artis
                break


def animehatacarpisma():
    global enemies
    global animes
    global slaps
    global kisses
    global mod
    global puan
    for i in range(len(enemies)):
        if osman.colliderect(enemies[i]):
            mod = "lose"

        for q in range(len(kisses)):
            if enemies[i].colliderect(kisses[q]):
                enemies.pop(i)
                kisses[q].pos = (10000, 10000)
                kisses.pop(q)
                newenemy()
                puan -= 5
                break


def slapdonme():
    global mod
    if keyboard.E:
        for i in range(len(slaps)):
            slaps[i].angle = slaps[i].angle_to(mousePos)


def kissdonme():
    global mod
    if keyboard.Q:
        for i in range(len(kisses)):
            kisses[i].angle = kisses[i].angle_to(mousePos)


def slaphareket():
    global mod
    for i in range(len(slaps)):
        if slaps[i].y > -20 and slaps[i].y < 620 and slaps[i].x > -20 and slaps[i].x < 1020:
            slaps[i].move_forward(10)
        else:
            slaps.pop(i)
            break


def kisshareket():
    global mod
    for i in range(len(kisses)):
        if kisses[i].y > -20 and kisses[i].y < 620 and kisses[i].x > -20 and kisses[i].x < 1020:
            kisses[i].move_forward(10)
        else:
            kisses.pop(i)
            break

def animekonum():
    for i in range(len(animes)):
        side = random.randint(1, 4)
        if side == 1:
            y = random.randint(-1000, -10)
            x = random.randint(-200, -10)
        if side == 2:
            y = random.randint(-1000, -10)
            x = random.randint(1010, 1200)
        if side == 3:
            y = random.randint(610, 1000)
            x = random.randint(-1000, -10)
        if side == 4:
            y = random.randint(610, 1000)
            x = random.randint(1010, 1200)

        animes[i].x = x
        animes[i].y = y

def enemykonum():
    for i in range(len(enemies)):
        side = random.randint(1, 4)
        if side == 1:
            y = random.randint(-1000, -10)
            x = random.randint(-200, -10)
        if side == 2:
            y = random.randint(-1000, -10)
            x = random.randint(1010, 1200)
        if side == 3:
            y = random.randint(610, 1000)
            x = random.randint(-1000, -10)
        if side == 4:
            y = random.randint(610, 1000)
            x = random.randint(1010, 1200)

        enemies[i].x = x
        enemies[i].y = y


def on_key_down(key):
    global mod
    global aless
    global dhiz
    global ahiz
    global impo
    global kb
    if mod == "tanıt" and keyboard.space:
        mod = "start"

    if keyboard.s:
        mod = "secti"

    if keyboard.w:
        global start
        mod = "oyun"
        start = time.time()

        if kontrol == -1:
            aless = 5
            ahiz = 3
            dhiz = 4
        if kontrol == 1:
            ahiz = 2
            dhiz = 3
            aless = 4
        if kontrol == 0:
            ahiz = 2
            dhiz = 2
            aless = 4

    if mod == "oyun":
        if keyboard.e:
            slap.pos = osman.pos
            slaps.append(slap)

        if keyboard.q:
            kiss.pos = osman.pos
            kisses.append(kiss)

    if mod == "haber":
        if keyboard.x:
            if para == -1:
                mod = "lose"

            if para == 1:
                mod = "eleme"

    if mod == "eleme":
        global impo
        if (keyboard.k_1 and impo == 1) or (keyboard.k_2 and impo == 2) or (keyboard.k_3 and impo == 3) or (keyboard.k_4 and impo == 4) or (keyboard.k_5 and impo == 5) or (keyboard.k_6 and impo == 6): #sayı girdisi
            mod = "lose"
        else:
            if keyboard.k_1:
                kb = 1
                mod = "son"
            if keyboard.k_2:
                kb = 2
                mod = "son"
            if keyboard.k_3:
                kb = 3
                mod = "son"
            if keyboard.k_4:
                kb = 4
                mod = "son"
            if keyboard.k_5:
                kb = 5
                mod = "son"
            if keyboard.k_6:
                kb = 6
                mod = "son"



    if mod == "son" and keyboard.v:
        mod = "win"



def update(dt):
    global mod
    global timer_int
    timer = time.time() - start
    timer_int = int(timer)
    if mod == "oyun":
        if timer <= 40:
            slaphareket()
            slapdonme()
            kisshareket()
            kissdonme()
            kisshareket()
            newenemy()
            newanime()
            sumocarpisma()
            animecarpisma()
            sumohatacarpisma()
            animehatacarpisma()
            enemydonme()
            animedonme()
            enemymove()
            animemove()
        else:
            enemykonum()
            animekonum()


        if timer > 40 and dhiz == 2:
            mod = "ikinci"
        elif timer > 40 and dhiz > 2:
            mod = "haber"


def on_mouse_move(pos):
    global mousePos
    mousePos = pos


def on_mouse_down(pos, button):
    global mod
    global dhiz
    global ahiz
    global aless
    global iks, ye
    global basma
    global buttonx

    if buttonx.collidepoint(pos) and basma < 3:
        basma += 1
        iks, ye = random.randint(200,800), random.randint(200,400)
        buttonx = Actor("panel", (iks, ye))

    if buttonx.collidepoint(pos) and button == mouse.RIGHT and  basma >= 3:
        mod = "menu1"
    if dialog1.collidepoint(pos) and button == mouse.LEFT:
        mod = "menu2"
    if dialog2.collidepoint(pos) and button == mouse.LEFT:
        mod = "menu3"
    if button1.collidepoint(pos) and button == mouse.LEFT:
        global start
        start = time.time()
        mod = "oyun"
    if button4.collidepoint(pos) and button == mouse.LEFT:
        mod = "ucuncu"



pgzrun.go()
